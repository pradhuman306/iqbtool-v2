<?php


/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'comiqbtool_iqbtool' );

/** Database username */
define( 'DB_USER', 'comiqbtool_iqbtool' );

/** Database password */
define( 'DB_PASSWORD', 'comiqbtool_Iqbtool' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'sp&!A{SjL%7QbpSRQS?KyHwC0G2wwt x[9j5)koPYecowBC-gHFx8M!]z%J!L@)}' );
define( 'SECURE_AUTH_KEY',   ',bHMis#$OZ]<$,V}IMbk%6FS9as!gB2B7VljG5p.3i_PKtt!8i]<S1GIr8Ms[GIw' );
define( 'LOGGED_IN_KEY',     '%G&PB@qT<(wDz^|o6QY?Ce*AdLOHRaUy^iJsqrR+xW!=,$x:Iz68qFgMOKo_zbgs' );
define( 'NONCE_KEY',         'hPU.hQIy,{1(jj5hm4YpLJ#c[!MFA:}1]HUk4Qd4]DiIw,Nzl1 b>P-)^x3_tQy-' );
define( 'AUTH_SALT',         'eI!-P1b{|P{&op0040/z0`6kU&NWeAPySfZ/1Pzl0LHWLDQMkU(^J@Usq]yBN)(Z' );
define( 'SECURE_AUTH_SALT',  '%XOC_G1xS3}g6S_==&[>~JFZf`Acx%+#0sA57z&Jr?Ze1<nzn5^+%<U1529},=;Z' );
define( 'LOGGED_IN_SALT',    '4?r2Zj4(izz@-v< +5KGy`lB.vcJu#mq(IX+nMz0+p(ZBzD}VRrMZ.:Y~rN! &Y]' );
define( 'NONCE_SALT',        'h)N*7|OTp }dK_U&v+mg$lI=)TRNZmu%s=yNAFj|ZOK):Gy.RM%R)ECwq+n>xYii' );
define( 'WP_CACHE_KEY_SALT', '+Ty:MwGYjSsfS>a!iF.#<mp5dE])c5E!hqi509R=Mqk/OcvWhIlar2@$H^|0N/N?' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', true );
}

define( 'FS_METHOD', 'direct' );
define( 'WP_AUTO_UPDATE_CORE', 'minor' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
